<?php
session_start();

require_once __DIR__ . '/php/conexao.php';

// Verifica se o usuário está logado
$usuarioLogado = isset($_SESSION['usuario_id']);
$nomeUsuario = $_SESSION['nm_usuario'] ?? 'Visitante';
$fotoUsuario = $_SESSION['usuario_foto'] ?? 'image/imguser.png';

// Consulta das publicações
$publicacoes = [];
$sql = "SELECT p.id_publicacao, p.nm_publicacao, p.descricao, p.img_publicacao, u.nm_usuario 
        FROM tb_publicacao p
        JOIN tb_usuarios u ON p.tb_usuarios_id_usuarios = u.id_usuarios
        ORDER BY p.id_publicacao DESC";

if ($stmt = $mysqli->prepare($sql)) {
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) {
        $publicacoes[] = $row;
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Publicações - EcotechRoots</title>
    <link rel="shortcut icon" href="favicon.com/favicon.png" type="image/x-icon" />
    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet" />
    <link rel="stylesheet" href="css/style.css" />
    <style>
    /* Seu estilo customizado pode continuar aqui */
    /* Ou importe seu style.css como já faz */
    </style>
</head>
<body>

<!-- Navbar igual ao da tela inicial -->
<header class="d-flex align-items-center px-4 py-2" style="background-color: #234d37; color: #FEFFF1; position: fixed; top: 0; width: 100%; height: 60px; z-index: 1000;">
    <a href="telainicial.php" class="d-flex align-items-center gap-2 me-auto">
        <img src="image/logo ecotech.png" alt="Logo EcotechRoots" width="80" height="80" />
    </a>
    <span class="fw-bold text-white mx-auto">EcotechRoots</span>

    <?php if ($usuarioLogado): ?>
        <a href="perfil.php" class="user-profile ms-auto" style="display:flex; align-items:center; gap:10px;">
            <img src="<?= htmlspecialchars($fotoUsuario) ?>" alt="Foto do Usuário" style="width:45px; height:45px; border-radius:50%; object-fit:cover; border:2px solid #fff;" />
            <form action="php/logout.php" method="post" style="margin:0;">
                <button type="submit" class="btn btn-outline-light btn-sm">Sair</button>
            </form>
        </a>
    <?php else: ?>
        <a href="telalogin.php" class="fw-bold text-white text-decoration-none ms-auto">Entrar</a>
    <?php endif; ?>
</header>

<div class="d-flex min-vh-100" style="padding-top: 60px;">
    <!-- SIDEBAR -->
    <aside class="sidebar d-none d-md-flex flex-column p-4 text-white" style="background: #234d37; width: 220px; position: fixed; top: 60px; bottom: 0;">
        <nav class="nav flex-column gap-2">
            <a class="nav-link" href="telainicial.php">Início</a>
            <a class="nav-link" href="telaprojeto.html">Projeto</a>
            <a class="nav-link" href="telaconcientizacao.html">Conscientização</a>
            <a class="nav-link" href="telapin.html">Mapa Pin</a>
            <a class="nav-link" href="publicacoes.php">Publicação</a>
            <a class="nav-link" href="sobre.html">Sobre nós</a>
        </nav>
        <div class="mt-auto">
            <div class="small mt-2">© 2025 Ecotech</div>
        </div>
    </aside>

    <!-- CONTEÚDO PRINCIPAL -->
    <main style="margin-left: 220px; padding: 20px; flex-grow:1;">
        <h1>Publicações da Comunidade</h1>
        <p>Bem-vindo, <strong><?= htmlspecialchars($nomeUsuario) ?></strong></p>

        <?php if (count($publicacoes) > 0): ?>
            <?php foreach ($publicacoes as $p): ?>
                <div class="publicacao" style="border: 1px solid #ccc; padding: 15px; margin-bottom: 15px; border-radius: 8px; background: #f9f9f9;">
                    <h2><?= htmlspecialchars($p['nm_publicacao']) ?></h2>
                    <p><strong>Autor:</strong> <?= htmlspecialchars($p['nm_usuario']) ?></p>
                    <?php if (!empty($p['img_publicacao'])): ?>
                        <img src="<?= htmlspecialchars($p['img_publicacao']) ?>" alt="Imagem da publicação" style="max-width: 100%; height: auto; border-radius: 8px;" />
                    <?php endif; ?>
                    <p><?= nl2br(htmlspecialchars($p['descricao'])) ?></p>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>Nenhuma publicação encontrada.</p>
        <?php endif; ?>
    </main>
</div>

<script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>
